package com.example.linkedlistapplicationdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LinkedListApplicationDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(LinkedListApplicationDemoApplication.class, args);
    }

}
